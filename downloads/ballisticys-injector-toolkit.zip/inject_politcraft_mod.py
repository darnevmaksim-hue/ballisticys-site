#!/usr/bin/env python3
"""Auto-inject Ballisticys Fabric mod into PolitCraft launcher profile.

What it does:
1. Copies agent/mod jars into PolitCraft custom libraries directory.
2. Creates a timestamped backup of profileInfo.json.
3. Rewrites data.arguments in profileInfo.json to include:
   -Dfabric.addMods=...
   -javaagent:...ballisticys-fabric-agent...=mods=...;watch=...
"""

from __future__ import annotations

import argparse
import json
import os
import re
import shutil
import sys
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path

RESET = "\033[0m"
BOLD = "\033[1m"
DIM = "\033[2m"
RED = "\033[31m"
GREEN = "\033[32m"
YELLOW = "\033[33m"
CYAN = "\033[36m"


def c(text: str, color: str) -> str:
    if not sys.stdout.isatty():
        return text
    return f"{color}{text}{RESET}"


@dataclass
class InjectConfig:
    profile: str
    watch_class: str
    appdata_root: Path
    workspace_root: Path
    mod_jar: Path
    agent_jar: Path
    dry_run: bool


def default_workspace_root() -> Path:
    return Path(__file__).resolve().parent


def default_appdata_root() -> Path:
    return Path(os.environ.get("APPDATA", r"C:\Users\comp\AppData\Roaming")) / "politcraft"


def resolve_first_existing(paths: list[Path]) -> Path:
    for p in paths:
        if p.exists():
            return p
    return paths[0]


def default_agent_jar(workspace_root: Path) -> Path:
    candidates = [
        workspace_root / "ballisticys-fabric-agent-1.0.0.jar",
        workspace_root / "inject-agent" / "build" / "libs" / "ballisticys-fabric-agent-1.0.0.jar",
    ]
    return resolve_first_existing(candidates)


def default_mod_jar(workspace_root: Path) -> Path:
    preferred = [
        workspace_root / "bbb-fabric-port-2.0pre4-fabric-port.jar",
        workspace_root / "_tmp_bbb-fabric-2.0pre4.jar",
        workspace_root / "_tmp_restore_test.jar",
    ]
    for p in preferred:
        if p.exists():
            return p

    dynamic = sorted(
        [
            p
            for p in workspace_root.glob("*.jar")
            if "ballisticys-fabric-agent" not in p.name.lower()
            and "authlib-injector" not in p.name.lower()
        ],
        key=lambda p: p.stat().st_mtime,
        reverse=True,
    )
    if dynamic:
        return dynamic[0]

    return preferred[0]


def parse_args() -> InjectConfig:
    workspace_root = default_workspace_root()

    parser = argparse.ArgumentParser(
        description="Inject Ballisticys mod into PolitCraft profile arguments.",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )
    parser.add_argument("--profile", default="PolitCraft-3", help="PolitCraft profile folder name")
    parser.add_argument("--watch-class", default="net.minecraft.client.MinecraftClient", help="watch= class for agent args")
    parser.add_argument("--appdata-root", type=Path, default=default_appdata_root(), help="Root of PolitCraft data")
    parser.add_argument("--mod-jar", type=Path, default=default_mod_jar(workspace_root), help="Path to mod jar")
    parser.add_argument("--agent-jar", type=Path, default=default_agent_jar(workspace_root), help="Path to Java agent jar")
    parser.add_argument("--dry-run", action="store_true", help="Show actions without writing files")

    ns = parser.parse_args()
    return InjectConfig(
        profile=ns.profile,
        watch_class=ns.watch_class,
        appdata_root=ns.appdata_root,
        workspace_root=workspace_root,
        mod_jar=ns.mod_jar,
        agent_jar=ns.agent_jar,
        dry_run=ns.dry_run,
    )


def build_paths(cfg: InjectConfig) -> tuple[Path, Path, Path]:
    profile_info = cfg.appdata_root / "offline-mode" / cfg.profile / "profileInfo.json"
    custom_libs = cfg.appdata_root / "game data" / cfg.profile / "libraries" / "custom"
    return profile_info, custom_libs, cfg.appdata_root


def ensure_exists(path: Path, label: str) -> None:
    if not path.exists():
        raise FileNotFoundError(f"{label} not found: {path}")


def backup_file(path: Path, dry_run: bool) -> Path:
    stamp = datetime.now().strftime("%Y%m%d-%H%M%S-%f")
    bak = path.with_name(f"{path.name}.bak-agent-{stamp}")
    if not dry_run:
        shutil.copy2(path, bak)
    return bak


def remove_old_injection(args_line: str) -> str:
    out = args_line
    out = re.sub(r'"-javaagent:[^"]*ballisticys-fabric-agent[^"]*"', "", out, flags=re.IGNORECASE)
    out = re.sub(r'"-Dfabric\.addMods=[^"]*"', "", out, flags=re.IGNORECASE)
    out = re.sub(r"\s{2,}", " ", out).strip()
    return out


def inject_args(args_line: str, javaagent_arg: str, fabric_arg: str) -> str:
    args_line = remove_old_injection(args_line)
    injection = f" {fabric_arg} {javaagent_arg}"
    marker = " net.fabricmc.loader.impl.launch.knot.KnotClient"
    idx = args_line.find(marker)
    if idx >= 0:
        return (args_line[:idx] + injection + args_line[idx:]).strip()
    return (args_line + injection).strip()


def count_occurrences(args_line: str) -> tuple[int, int]:
    fabric_count = len(re.findall(r"-Dfabric\.addMods=", args_line, flags=re.IGNORECASE))
    agent_count = len(re.findall(r"-javaagent:[^\"]*ballisticys-fabric-agent", args_line, flags=re.IGNORECASE))
    return fabric_count, agent_count


def write_json(path: Path, data: dict, dry_run: bool) -> None:
    payload = json.dumps(data, ensure_ascii=False, separators=(",", ":"))
    if not dry_run:
        path.write_text(payload, encoding="utf-8")


def main() -> int:
    cfg = parse_args()

    print(c("\nBallisticys Auto Injector", BOLD + CYAN))
    print(c("=" * 28, CYAN))

    profile_info, custom_libs, _ = build_paths(cfg)

    try:
        ensure_exists(cfg.mod_jar, "Mod jar")
        ensure_exists(cfg.agent_jar, "Agent jar")
        ensure_exists(profile_info, "Profile JSON")
    except FileNotFoundError as exc:
        print(c(f"ERROR: {exc}", RED))
        return 1

    mod_dst = custom_libs / cfg.mod_jar.name
    agent_dst = custom_libs / cfg.agent_jar.name

    print(f"{c('Profile:', BOLD)} {cfg.profile}")
    print(f"{c('Profile JSON:', BOLD)} {profile_info}")
    print(f"{c('Custom libs:', BOLD)} {custom_libs}")
    print(f"{c('Mod source:', BOLD)} {cfg.mod_jar}")
    print(f"{c('Agent source:', BOLD)} {cfg.agent_jar}")
    if cfg.dry_run:
        print(c("Mode: DRY-RUN (no file writes)", YELLOW))

    if not cfg.dry_run:
        custom_libs.mkdir(parents=True, exist_ok=True)
        shutil.copy2(cfg.mod_jar, mod_dst)
        shutil.copy2(cfg.agent_jar, agent_dst)
    print(c("OK: jars synced to custom libs", GREEN))

    raw = profile_info.read_text(encoding="utf-8-sig")
    data = json.loads(raw)
    if "data" not in data or "arguments" not in data["data"]:
        print(c("ERROR: profileInfo.json has unexpected format (missing data.arguments)", RED))
        return 1

    virtual_base = f"{{localPath}}/game data/{cfg.profile}/libraries/custom"
    mod_virtual = f"{virtual_base}/{mod_dst.name}"
    agent_virtual = f"{virtual_base}/{agent_dst.name}"

    fabric_arg = f'"-Dfabric.addMods={mod_virtual}"'
    javaagent_arg = (
        f'"-javaagent:{agent_virtual}=mods={mod_virtual};watch={cfg.watch_class}"'
    )

    old_args = str(data["data"]["arguments"])
    new_args = inject_args(old_args, javaagent_arg, fabric_arg)
    data["data"]["arguments"] = new_args

    fabric_count, agent_count = count_occurrences(new_args)
    if fabric_count != 1 or agent_count != 1:
        print(c("ERROR: validation failed after patch (expected exactly 1 fabric.addMods and 1 ballisticys javaagent)", RED))
        print(c(f"fabric.addMods={fabric_count}, ballisticys-javaagent={agent_count}", RED))
        return 1

    bak = backup_file(profile_info, cfg.dry_run)
    write_json(profile_info, data, cfg.dry_run)

    print(c(f"OK: backup created -> {bak}", GREEN))
    print(c("OK: data.arguments updated with javaagent + fabric.addMods", GREEN))
    print(c(f"OK: validation passed (fabric.addMods={fabric_count}, ballisticys-javaagent={agent_count})", GREEN))
    print(c("Done.", BOLD + GREEN))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
