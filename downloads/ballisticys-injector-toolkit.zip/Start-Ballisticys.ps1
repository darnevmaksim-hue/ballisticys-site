$ErrorActionPreference = 'Stop'

function Write-Log {
    param([string]$Message)
    $ts = Get-Date -Format 'yyyy-MM-dd HH:mm:ss'
    $line = "[$ts] $Message"
    Write-Host $line
    Add-Content -LiteralPath $global:LogFile -Value $line -Encoding UTF8
}

$base = Split-Path -Parent $MyInvocation.MyCommand.Path
$global:LogFile = Join-Path $base 'inject-launch.log'

$agentJar = Join-Path $base 'payload\ballisticys-fabric-agent-1.0.0.jar'
$modJar = Get-ChildItem -LiteralPath (Join-Path $base 'payload') -Filter 'bbb-fabric-port-*.jar' -File |
    Sort-Object LastWriteTime -Descending |
    Select-Object -First 1

if (!(Test-Path -LiteralPath $agentJar)) { throw "Не найден агент: $agentJar" }
if ($null -eq $modJar) { throw 'Не найден Fabric jar (bbb-fabric-port-*.jar) в payload' }

$politcraftRoot = Join-Path $env:APPDATA 'politcraft'
$offlineRoot = Join-Path $politcraftRoot 'offline-mode'
if (!(Test-Path -LiteralPath $offlineRoot)) { throw "Не найдена папка: $offlineRoot" }

$profiles = Get-ChildItem -LiteralPath $offlineRoot -Recurse -File -Filter 'profileInfo.json' |
    Sort-Object LastWriteTime -Descending
if (!$profiles) { throw 'profileInfo.json не найден' }

Write-Log "Найдено профилей: $($profiles.Count)"

foreach ($p in $profiles) {
    try {
        $json = Get-Content -LiteralPath $p.FullName -Raw | ConvertFrom-Json
        $rel = $json.data.releativePath
        if ([string]::IsNullOrWhiteSpace($rel)) {
            if ($p.Directory -and $p.Directory.Name) { $rel = $p.Directory.Name } else { continue }
        }

        $libCustom = Join-Path (Join-Path (Join-Path $politcraftRoot 'game data') $rel) 'libraries\custom'
        New-Item -ItemType Directory -Force -Path $libCustom | Out-Null

        $agentDst = Join-Path $libCustom 'ballisticys-fabric-agent-1.0.0.jar'
        $modDst = Join-Path $libCustom $modJar.Name
        Copy-Item -LiteralPath $agentJar -Destination $agentDst -Force
        Copy-Item -LiteralPath $modJar.FullName -Destination $modDst -Force

        $args = [string]$json.data.arguments
        if ([string]::IsNullOrWhiteSpace($args)) { continue }

        $args = [regex]::Replace($args, '"?-javaagent:[^\s"]*ballisticys-fabric-agent-1\.0\.0\.jar[^\s"]*"?', '')

        $agentArgPath = "{localPath}/game data/$rel/libraries/custom/ballisticys-fabric-agent-1.0.0.jar"
        $modArgPath = "{localPath}/game data/$rel/libraries/custom/$($modJar.Name)"
        $injectArg = '"-javaagent:' + $agentArgPath + '=mods=' + $modArgPath + ';watch=net.minecraft.client.MinecraftClient"'

        if ($args -match 'net\.fabricmc\.loader\.impl\.launch\.knot\.KnotClient') {
            $args = [regex]::Replace($args, 'net\.fabricmc\.loader\.impl\.launch\.knot\.KnotClient', "$injectArg net.fabricmc.loader.impl.launch.knot.KnotClient", 1)
        } else {
            $args = "$args $injectArg"
        }

        $json.data.arguments = $args
        $json | ConvertTo-Json -Depth 100 | Set-Content -LiteralPath $p.FullName -Encoding UTF8

        $modsDir = Join-Path $p.Directory.FullName 'PolitCraft\mods'
        $old = Join-Path $modsDir 'bbb-fabric-2.0pre4.jar'
        if (Test-Path -LiteralPath $old) {
            Rename-Item -LiteralPath $old -NewName 'bbb-fabric-2.0pre4.jar.disabled' -Force
        }

        Write-Log "Профиль обновлён: $($p.FullName)"
    }
    catch {
        Write-Log "Ошибка профиля $($p.FullName): $($_.Exception.Message)"
    }
}

$preferredProfile = Join-Path $offlineRoot 'PolitCraft-3\profileInfo.json'
$primary = if (Test-Path -LiteralPath $preferredProfile) {
    Get-Item -LiteralPath $preferredProfile
} else {
    $profiles | Select-Object -First 1
}

Write-Log "Профиль запуска: $($primary.FullName)"

$primaryJson = Get-Content -LiteralPath $primary.FullName -Raw | ConvertFrom-Json
$localPath = $politcraftRoot
$java = [string]$primaryJson.data.javaPath
$args = [string]$primaryJson.data.arguments

if ([string]::IsNullOrWhiteSpace($java) -or [string]::IsNullOrWhiteSpace($args)) {
    throw 'Не удалось получить javaPath/arguments из profileInfo.json'
}

$java = $java.Replace('{localPath}', $localPath)
$args = $args.Replace('{localPath}', $localPath)
$hasAuthlibPlaceholder = ($args -match 'authlib-injector') -or ($args -match '\{authEndpoint\}')

$workDir = Split-Path -Parent $primary.FullName

$launcher = Join-Path $workDir 'PolitCraft.exe'
if (!(Test-Path -LiteralPath $launcher)) {
    $launcherCandidate = Get-ChildItem -LiteralPath $politcraftRoot -Recurse -File -Filter 'PolitCraft.exe' -ErrorAction SilentlyContinue |
        Sort-Object LastWriteTime -Descending |
        Select-Object -First 1
    if ($null -ne $launcherCandidate) {
        $launcher = $launcherCandidate.FullName
    } else {
        throw 'Не найден PolitCraft.exe для запуска.'
    }
}
Write-Log "Launcher: $launcher"

if ($hasAuthlibPlaceholder) {
    Start-Process -FilePath $launcher
    Write-Log 'Обнаружен authlib placeholder, запущен PolitCraft.exe (рекомендуемый режим).'
} else {
    try {
        $proc = Start-Process -FilePath $java -ArgumentList $args -WorkingDirectory $workDir -PassThru
        Start-Sleep -Seconds 6
        if ($proc.HasExited) {
            Write-Log "Прямой запуск завершился с кодом $($proc.ExitCode), запускаю PolitCraft.exe."
            Start-Process -FilePath $launcher
            Write-Log 'Запущен PolitCraft.exe (fallback).'
        } else {
            Write-Log 'Клиент запущен напрямую через java/knot.'
        }
    }
    catch {
        Write-Log "Прямой запуск не удался: $($_.Exception.Message)"
        Start-Process -FilePath $launcher
        Write-Log 'Запущен PolitCraft.exe (fallback).'
    }
}

